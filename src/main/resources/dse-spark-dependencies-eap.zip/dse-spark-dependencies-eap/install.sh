#!/bin/bash -ex

cd "$(dirname "$0")"

command -v mvn >/dev/null 2>&1 || { echo >&2 "Apache Maven(tm) must be intalled to run this script."; exit 1; }

VERSION=6.0.0-eap1

DSE_SPARK_DEPENDENCIES_POM=dse-spark-dependencies-$VERSION.pom
DSE_SPARK_DEPENDENCIES_JAR=dse-spark-dependencies-$VERSION.jar

mvn install:install-file -Dfile=$DSE_SPARK_DEPENDENCIES_JAR -DpomFile=$DSE_SPARK_DEPENDENCIES_POM
mvn install:install-file -Dfile=dse-graph-frames-$VERSION.jar -DpomFile=dse-graph-frames-$VERSION.pom

for DEP in dependencies/*; do
	FILENAME=$(basename $DEP)
    ARTIFACT_ID=${FILENAME/.jar/}

    mvn install:install-file -Dfile=$DEP -DgroupId=com.datastax.dse.eap -DartifactId=$ARTIFACT_ID -Dversion=$VERSION -Dpackaging=jar
done
